## 1) Import Libraries


```python
import pandas as pd
import numpy as np
import wbdata
import datetime
import matplotlib.pyplot as plt
import statsmodels.formula.api as smf
```

## 2) Data Collection

### Define World Bank indicators


```python
indicators = {
    
    "SP.DYN.TFRT.IN": "fertility_rate",
    "NY.GDP.PCAP.KD.ZG": "GDP_per_capita"
    
}
```


```python
countries = [
    
    "DEU", "FRA", "ITA", "ESP", "POL", "SWE", "NLD", "BEL", "GRC", "PRT",
    "CZE", "HUN", "ROU", "AUT", "CHE", "NOR", "DNK", "FIN", "SVK", "BGR",
    "HRV", "SVN", "LTU", "LVA", "EST", "IRL", "GBR", "UKR", "SRB", "ALB",

]
```

### Pull data from the World Bank API


```python
df = wbdata.get_dataframe (indicators, country = countries)

print(df.head(10))
```

                  fertility_rate  GDP_per_capita
    country date                                
    Albania 2025             NaN             NaN
            2024           1.341        5.663959
            2023           1.348        5.632935
            2022           1.355        6.456988
            2021           1.365       10.664149
            2020           1.371       -1.810165
            2019           1.395        3.649758
            2018           1.415        5.283579
            2017           1.486        4.889353
            2016           1.555        5.524826


## 3) Data Cleaning

### Check summary statistics to identify any data quality issues


```python
df.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>fertility_rate</th>
      <th>GDP_per_capita</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1950.000000</td>
      <td>1548.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>1.864498</td>
      <td>2.341305</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.597398</td>
      <td>4.314837</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.897000</td>
      <td>-31.177519</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>1.460000</td>
      <td>0.793556</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>1.730000</td>
      <td>2.480599</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>2.080000</td>
      <td>4.507024</td>
    </tr>
    <tr>
      <th>max</th>
      <td>6.383000</td>
      <td>42.016075</td>
    </tr>
  </tbody>
</table>
</div>



### Check missing value counts per variable


```python
df.isnull().sum()
```




    fertility_rate     30
    GDP_per_capita    432
    dtype: int64



### Drop all rows with missing values


```python
df = df.dropna()
```

### Reset index to bring country and date out as columns


```python
df_reset = df.reset_index()
```

### Convert date column to datetime format


```python
df_reset["date"] = pd.to_datetime (df_reset["date"])
```

### Trim to the 1990 to 2020 study period


```python
df_model = df_reset[
    
    (df_reset["date"].dt.year >= 1990) &
    (df_reset["date"].dt.year <= 2020)

].copy()
```

### Add a numeric year column for use in the fixed effects model


```python
df_model["year"] = df_model["date"].dt.year
```


```python
print(f"Date range: {df_model['year'].min()} to {df_model['year'].max()}")
```

    Date range: 1990 to 2020



```python
print(f"Observations: {df_model.shape[0]}")
```

    Observations: 915



```python
print(f"Countries: {df_model['country'].nunique()}")
```

    Countries: 30


## 4) Exploratory Data Analysis

### Chart 1: Fertility rate trends across all 30 countries with 2.1 replacement threshold


```python
plt.figure (figsize = (14, 6))

for country in df_model["country"].unique():
    country_data = df_model[df_model["country"] == country]
    plt.plot(country_data["date"], country_data["fertility_rate"], alpha = 0.5)

plt.axhline (y = 2.1, color = "red", linestyle = "--", linewidth = 1.5, label = "Replacement Level (2.1)")

plt.title ("Fertility Rate Across European Countries (1990-2020)")
plt.xlabel ("Year")
plt.ylabel ("Fertility Rate")

plt.legend()
plt.tight_layout()
plt.show()
```


    
![png](output_28_0.png)
    


### Chart 2: Rank 30 countries by average fertility rate 


```python
avg_fertility = df_model.groupby("country")["fertility_rate"].mean().sort_values()

plt.figure (figsize = (12, 8))
plt.barh (avg_fertility.index, avg_fertility.values, color = "steelblue")
plt.axvline (x = 2.1, color = "red", linestyle = "--", linewidth = 1.5, label = "Replacement Level (2.1)")

plt.title ("Average Fertility Rate by Country (1990-2020)")
plt.xlabel ("Average Fertility Rate")
plt.ylabel ("Country")

plt.legend()
plt.tight_layout()
plt.show()
```


    
![png](output_30_0.png)
    


### Chart 3: Raw relationship between fertility rate and GDP per capita


```python
plt.figure (figsize=(10, 6))
plt.scatter (df_model["fertility_rate"], df_model["GDP_per_capita"], alpha = 0.3, color = "steelblue")
plt.axvline (x = 2.1, color = "red", linestyle = "--", linewidth = 1.5, label = "Replacement Level (2.1)")

plt.title ("Fertility Rate vs GDP Per Capita (1990-2020)")
plt.xlabel ("Fertility Rate")
plt.ylabel ("GDP Per Capita Growth (%)")

plt.legend()
plt.tight_layout()
plt.show()
```


    
![png](output_32_0.png)
    


### Chart 4: Correlation heatmap between fertility rate and GDP growth


```python
corr_matrix = df_model[["fertility_rate", "GDP_per_capita"]].corr()

fig, ax = plt.subplots(figsize = (6, 5))
cax = ax.matshow(corr_matrix, cmap = "coolwarm")
fig.colorbar(cax)

ax.set_xticks(range(len(corr_matrix.columns)))
ax.set_yticks(range(len(corr_matrix.columns)))
ax.set_xticklabels(corr_matrix.columns, rotation=45, ha="left")
ax.set_yticklabels(corr_matrix.columns)

for i in range(len(corr_matrix)):
    for j in range(len(corr_matrix)):
        ax.text(j, i, f"{corr_matrix.iloc[i, j]:.2f}", ha="center", va="center", color="black")

plt.title ("Correlation Heatmap (1990-2020)", pad=20)
plt.tight_layout()
plt.show()
```


    
![png](output_34_0.png)
    


## 5) Panel Data Modelling (Fixed effects OLS regression)


```python
model_gdp = smf.ols(
    "GDP_per_capita ~ fertility_rate + C(country) + C(year)",
    data = df_model
).fit()

print(model_gdp.summary())
```

                                OLS Regression Results                            
    ==============================================================================
    Dep. Variable:         GDP_per_capita   R-squared:                       0.430
    Model:                            OLS   Adj. R-squared:                  0.390
    Method:                 Least Squares   F-statistic:                     10.76
    Date:                Wed, 01 Jul 2026   Prob (F-statistic):           6.31e-70
    Time:                        00:12:16   Log-Likelihood:                -2465.3
    No. Observations:                 915   AIC:                             5053.
    Df Residuals:                     854   BIC:                             5347.
    Df Model:                          60                                         
    Covariance Type:            nonrobust                                         
    =================================================================================================
                                        coef    std err          t      P>|t|      [0.025      0.975]
    -------------------------------------------------------------------------------------------------
    Intercept                        12.9999      2.082      6.244      0.000       8.913      17.087
    C(country)[T.Austria]            -5.1187      1.063     -4.815      0.000      -7.205      -3.032
    C(country)[T.Belgium]            -4.0055      0.984     -4.071      0.000      -5.937      -2.074
    C(country)[T.Bulgaria]           -4.1519      1.049     -3.958      0.000      -6.211      -2.093
    C(country)[T.Croatia]            -4.8340      1.053     -4.592      0.000      -6.900      -2.768
    C(country)[T.Czechia]            -4.6426      1.068     -4.346      0.000      -6.739      -2.546
    C(country)[T.Denmark]            -3.6108      0.969     -3.728      0.000      -5.512      -1.710
    C(country)[T.Estonia]            -3.0675      1.036     -2.962      0.003      -5.100      -1.035
    C(country)[T.Finland]            -3.7372      0.975     -3.834      0.000      -5.650      -1.824
    C(country)[T.France]             -3.3587      0.950     -3.536      0.000      -5.223      -1.495
    C(country)[T.Germany]            -5.2126      1.079     -4.830      0.000      -7.331      -3.094
    C(country)[T.Greece]             -6.3156      1.101     -5.737      0.000      -8.476      -4.155
    C(country)[T.Hungary]            -4.5448      1.057     -4.298      0.000      -6.620      -2.470
    C(country)[T.Ireland]             0.3850      0.947      0.407      0.684      -1.473       2.243
    C(country)[T.Italy]              -6.5817      1.112     -5.921      0.000      -8.763      -4.400
    C(country)[T.Latvia]             -3.5867      1.066     -3.366      0.001      -5.678      -1.495
    C(country)[T.Lithuania]          -3.1784      1.044     -3.045      0.002      -5.227      -1.129
    C(country)[T.Netherlands]        -3.8114      0.990     -3.849      0.000      -5.755      -1.868
    C(country)[T.Norway]             -3.1688      0.959     -3.304      0.001      -5.051      -1.286
    C(country)[T.Poland]             -2.5570      1.064     -2.404      0.016      -4.645      -0.469
    C(country)[T.Portugal]           -5.2540      1.070     -4.911      0.000      -7.354      -3.154
    C(country)[T.Romania]            -3.3400      1.050     -3.181      0.002      -5.401      -1.279
    C(country)[T.Serbia]             -3.2202      1.096     -2.937      0.003      -5.372      -1.068
    C(country)[T.Slovak Republic]    -3.7007      1.064     -3.479      0.001      -5.789      -1.613
    C(country)[T.Slovenia]           -4.6374      1.078     -4.300      0.000      -6.754      -2.521
    C(country)[T.Spain]              -6.0092      1.127     -5.331      0.000      -8.221      -3.797
    C(country)[T.Sweden]             -3.3234      0.961     -3.458      0.001      -5.210      -1.437
    C(country)[T.Switzerland]        -5.3535      1.042     -5.137      0.000      -7.399      -3.308
    C(country)[T.Ukraine]            -7.4230      1.090     -6.807      0.000      -9.563      -5.283
    C(country)[T.United Kingdom]     -3.5755      0.967     -3.696      0.000      -5.474      -1.677
    C(year)[T.1991]                  -5.6577      1.081     -5.234      0.000      -7.779      -3.536
    C(year)[T.1992]                  -5.0359      1.080     -4.661      0.000      -7.157      -2.915
    C(year)[T.1993]                  -2.4817      1.082     -2.293      0.022      -4.606      -0.358
    C(year)[T.1994]                   0.4931      1.086      0.454      0.650      -1.638       2.624
    C(year)[T.1995]                   1.7601      1.090      1.614      0.107      -0.380       3.900
    C(year)[T.1996]                   1.2107      1.086      1.115      0.265      -0.920       3.342
    C(year)[T.1997]                   1.1753      1.089      1.079      0.281      -0.962       3.312
    C(year)[T.1998]                   1.4716      1.093      1.347      0.178      -0.673       3.617
    C(year)[T.1999]                  -0.0323      1.094     -0.030      0.976      -2.179       2.114
    C(year)[T.2000]                   2.4323      1.090      2.231      0.026       0.292       4.572
    C(year)[T.2001]                   1.5224      1.094      1.392      0.164      -0.625       3.670
    C(year)[T.2002]                   1.0237      1.094      0.936      0.350      -1.123       3.171
    C(year)[T.2003]                   1.1086      1.091      1.016      0.310      -1.033       3.251
    C(year)[T.2004]                   2.5999      1.088      2.389      0.017       0.464       4.736
    C(year)[T.2005]                   1.9375      1.087      1.782      0.075      -0.196       4.071
    C(year)[T.2006]                   3.1809      1.084      2.936      0.003       1.054       5.308
    C(year)[T.2007]                   3.1779      1.081      2.939      0.003       1.056       5.300
    C(year)[T.2008]                  -0.1421      1.077     -0.132      0.895      -2.256       1.972
    C(year)[T.2009]                  -7.1071      1.077     -6.601      0.000      -9.220      -4.994
    C(year)[T.2010]                   0.0276      1.077      0.026      0.980      -2.086       2.141
    C(year)[T.2011]                   0.2793      1.080      0.259      0.796      -1.840       2.398
    C(year)[T.2012]                  -1.6265      1.079     -1.507      0.132      -3.745       0.492
    C(year)[T.2013]                  -1.1640      1.081     -1.076      0.282      -3.287       0.958
    C(year)[T.2014]                   0.1980      1.080      0.183      0.855      -1.921       2.317
    C(year)[T.2015]                   1.0802      1.080      1.000      0.317      -1.039       3.199
    C(year)[T.2016]                   0.7138      1.078      0.662      0.508      -1.402       2.830
    C(year)[T.2017]                   1.8380      1.080      1.703      0.089      -0.281       3.957
    C(year)[T.2018]                   1.3671      1.081      1.264      0.206      -0.755       3.489
    C(year)[T.2019]                   0.8035      1.083      0.742      0.458      -1.322       2.929
    C(year)[T.2020]                  -6.0261      1.086     -5.551      0.000      -8.157      -3.895
    fertility_rate                   -4.6563      0.819     -5.687      0.000      -6.263      -3.049
    ==============================================================================
    Omnibus:                      355.358   Durbin-Watson:                   1.114
    Prob(Omnibus):                  0.000   Jarque-Bera (JB):             4043.590
    Skew:                          -1.439   Prob(JB):                         0.00
    Kurtosis:                      12.888   Cond. No.                         76.9
    ==============================================================================
    
    Notes:
    [1] Standard Errors assume that the covariance matrix of the errors is correctly specified.


## 6) Results Summary


```python
coef = round (model_gdp.params["fertility_rate"], 4)
pval = round (model_gdp.pvalues["fertility_rate"], 3)
rsq = round (model_gdp.rsquared, 3)
obs = int (model_gdp.nobs)

print("Fixed Effects Panel Regression Results")
print("Dependent Variable: GDP Per Capita Growth")

print("=" * 45)
print(f"Fertility Rate Coefficient : {coef}")
print(f"P-Value                    : {pval}")
print(f"R-Squared                  : {rsq}")
print(f"Observations               : {obs}")
print(f"Countries                  : 30")
print(f"Period                     : 1990 to 2020")
print("=" * 45)
print(f"Significant at 1% level    : {'Yes' if pval < 0.01 else 'No'}")
```

    Fixed Effects Panel Regression Results
    Dependent Variable: GDP Per Capita Growth
    =============================================
    Fertility Rate Coefficient : -4.6563
    P-Value                    : 0.0
    R-Squared                  : 0.43
    Observations               : 915
    Countries                  : 30
    Period                     : 1990 to 2020
    =============================================
    Significant at 1% level    : Yes

